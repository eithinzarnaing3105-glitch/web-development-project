const DETAIL_ROUTES = {
  "the-conjuring-last-rites": "./conjuring.html",
  "superman-legacy": "superman.html",
  "wednesday-s2": "wednesday_s2.html",
};
const DETAILS_BASE = ""; // Add this line at the top
// ...existing code...
export function initHome(RAW) {
  const $ = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => [...el.querySelectorAll(s)];

  const state = { tab: "All", year: null, genre: null, rating: null, q: "" };
  let ALL = [];
  let FILTERS = RAW.filters;

  // Flatten unique items across sections
  const map = new Map();
  RAW.sections.forEach((sec) =>
    sec.items.forEach((m) => {
      if (!map.has(m.id)) map.set(m.id, m);
    })
  );
  ALL = [...map.values()];

  buildDropdowns();
  wireControls();
  render();

  function buildDropdowns() {
    const yearSel = $("#filter-year");
    const buckets = [
      { label: "2025", from: 2025, to: 2025 },
      { label: "2020–2024", from: 2020, to: 2024 },
      { label: "2010–2019", from: 2010, to: 2019 },
    ];
    yearSel.innerHTML =
      `<option value="">Release year</option>` +
      buckets
        .map((b, i) => `<option value="${i}">${b.label}</option>`)
        .join("");
    yearSel.dataset.map = JSON.stringify(buckets);

    const genreSel = $("#filter-genre");
    genreSel.innerHTML =
      `<option value="">Genres</option>` +
      FILTERS.genres.map((g) => `<option value="${g}">${g}</option>`).join("");

    const ratingSel = $("#filter-rating");
    const rb = [
      { label: "4.5+", from: 4.5, to: 5.0 },
      { label: "4.0–4.4", from: 4.0, to: 4.4 },
      { label: "3.5–3.9", from: 3.5, to: 3.9 },
    ];
    ratingSel.innerHTML =
      `<option value="">Rating</option>` +
      rb.map((b, i) => `<option value="${i}">${b.label}</option>`).join("");
    ratingSel.dataset.map = JSON.stringify(rb);
  }

  function wireControls() {
    $$(".tab").forEach((btn) => {
      btn.addEventListener("click", () => {
        $$(".tab").forEach((b) => {
          b.classList.remove("active");
          b.setAttribute("aria-selected", "false");
        });
        btn.classList.add("active");
        btn.setAttribute("aria-selected", "true");
        state.tab = btn.dataset.tab;
        render();
      });
    });

    $("#filter-year").addEventListener("change", (e) => {
      const m = JSON.parse(e.target.dataset.map);
      state.year = e.target.value === "" ? null : m[Number(e.target.value)];
      render();
    });
    $("#filter-genre").addEventListener("change", (e) => {
      state.genre = e.target.value || null;
      render();
    });
    $("#filter-rating").addEventListener("change", (e) => {
      const m = JSON.parse(e.target.dataset.map);
      state.rating = e.target.value === "" ? null : m[Number(e.target.value)];
      render();
    });

    $("#reset-filters").addEventListener("click", () => {
      state.year = state.genre = state.rating = null;
      $("#filter-year").value = "";
      $("#filter-genre").value = "";
      $("#filter-rating").value = "";
      render();
    });

    const input = $("#search");
    let t = 0;
    input.addEventListener("input", (e) => {
      clearTimeout(t);
      const v = e.target.value;
      t = setTimeout(() => {
        state.q = v.trim();
        render();
      }, 180);
    });

    /* $("#sections-root").addEventListener("click", (e) => {
      const card = e.target.closest(".card");
      if (card) {
        const id = card.dataset.id;
        // Replace with your router
        console.log("navigate to ./details.html/" + id);
        //window.location.href = `./${DETAIL_ROUTES[id] || id + ".html"}`;
      }
    });*/

    $("#sections-root").addEventListener("click", (e) => {
      // 1) If "Add" button clicked, don't navigate
      const addBtn = e.target.closest(".add-btn");
      if (addBtn) {
        e.preventDefault();
        e.stopPropagation();
        const card = addBtn.closest(".card");
        if (card) console.log("add to list:", card.dataset.id);
        return;
      }

      // 2) If a card (or its internal link) was clicked and you want SEPARATE FILES:
      const card = e.target.closest(".card");
      if (card) {
        const id = card.dataset.id;
        const file = DETAIL_ROUTES[id] || `${id}.html`;

        // Intercept the default <a href="details.html?..."> and go to your file instead
        e.preventDefault();
        e.stopPropagation();
        window.location.href = DETAILS_BASE + file;
      }
    });
  }

  function render() {
    const root = $("#sections-root");
    root.innerHTML = "";

    RAW.sections.forEach((section) => {
      const items = section.items.filter(pass);
      if (!items.length) return;

      const sec = document.createElement("section");
      sec.className = "shelf";
      sec.innerHTML = `
        <div class="shelf-head">
          <h2>${section.title}</h2>
          <button class="shelf-next" aria-label="Next">
            <svg width="28" height="28" viewBox="0 0 33 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M27.5 16L28.0221 15.4616L28.5774 16L28.0221 16.5384L27.5 16ZM6.875 16.75C6.46079 16.75 6.125 16.4142 6.125 16C6.125 15.5858 6.46079 15.25 6.875 15.25V16V16.75ZM19.25 8L19.7721 7.46157L28.0221 15.4616L27.5 16L26.9779 16.5384L18.7279 8.53843L19.25 8ZM27.5 16L28.0221 16.5384L19.7721 24.5384L19.25 24L18.7279 23.4616L26.9779 15.4616L27.5 16ZM27.5 16V16.75H6.875V16V15.25H27.5V16Z" fill="#EC0000"/>
            </svg>
          </button>
        </div>
        <div class="carousel">
          ${items.map(cardHTML).join("")}
        </div>
      `;
      root.appendChild(sec);

      const c = sec.querySelector(".carousel");
      sec.querySelector(".shelf-next").addEventListener("click", () => {
        c.scrollBy({ left: c.clientWidth * 0.9, behavior: "smooth" });
      });
    });

    if (!root.children.length) {
      root.innerHTML = `<p class="empty">No results. Try adjusting filters or search.</p>`;
    }
  }

  function pass(m) {
    if (state.tab === "Movies" && m.type !== "Movie") return false;
    if (state.tab === "TV Shows" && m.type !== "TV") return false;
    if (state.year && !(m.year >= state.year.from && m.year <= state.year.to))
      return false;
    if (state.genre && !m.genres.includes(state.genre)) return false;
    if (
      state.rating &&
      !(m.rating >= state.rating.from && m.rating <= state.rating.to)
    )
      return false;
    if (state.q) {
      const q = state.q.toLowerCase();
      const hay = [m.title, m.type, ...(m.genres || [])]
        .join(" • ")
        .toLowerCase();
      if (!hay.includes(q)) return false;
    }
    return true;
  }

  function cardHTML(m) {
    return `
      <a href="./details.html?id=${m.id}" class="card" data-id="${
      m.id
    }" tabindex="0">
        <div class="poster">
          <img loading="lazy" src="${m.poster}" alt="${m.title} poster">
          <button class="add-btn" title="Add to list" aria-label="Add ${
            m.title
          }">
            <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M9 4.5L9 13.5" stroke="white" stroke-width="2" stroke-linecap="round"/>
            <path d="M13.5 9L4.5 9" stroke="white" stroke-width="2" stroke-linecap="round"/>
            </svg>
          </button>
        </div>
        <h3 class="title">${m.title}</h3>
        <div class="meta"><span class="star">★</span>${m.rating.toFixed(
          1
        )}</div>
      </a>
    `;
  }
}
