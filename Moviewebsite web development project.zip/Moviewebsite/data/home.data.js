export const HOME_DATA = {
  meta: { version: "1.0", generatedAt: "2025-09-16T00:00:00Z" },
  filters: {
    tabs: ["All", "Movies", "TV Shows"],
    genres: [
      "Action", "Adventure", "Drama", "Horror",
      "Comedy", "Sci-Fi", "Thriller", "Mystery"
    ],
    releaseYear: { min: 2000, max: 2025 },
    ratingScale: "0–5"
  },
  sections: [
    {
      id: "movies-you-might-like",
      title: "Movies You Might Like",
      items: [
        {
          id: "wednesday-s2",
          title: "Wednesday (Season 2)",
          type: "TV",
          genres: ["Horror", "Mystery"],
          year: 2025,
          rating: 4.8,
          poster: "./posters/wednesday_s2.jpg"
        },
        {
          id: "the-conjuring-last-rites",
          title: "The Conjuring: Last Rites",
          type: "Movie",
          genres: ["Horror", "Thriller"],
          year: 2024,
          rating: 4.2,
          poster: "./posters/conjuring_last_rites.jpeg"
        },
        {
          id: "oppenheimer",
          title: "Oppenheimer",
          type: "Movie",
          genres: ["Drama", "History"],
          year: 2023,
          rating: 4.8,
          poster: "./posters/oppenheimer.jpeg"
        },
        {
          id: "the-black-phone",
          title: "The Black Phone",
          type: "Movie",
          genres: ["Horror", "Thriller"],
          year: 2021,
          rating: 4.2,
          poster: "./posters/the_black_phone.jpg"
        },
        {
          id: "dexter-resurrection",
          title: "Dexter: Resurrection",
          type: "TV",
          genres: ["Thriller", "Crime"],
          year: 2025,
          rating: 4.2,
          poster: "./posters/dexter_resurrection.jpeg"
        },
        {
          id: "dune-part-two",
          title: "Dune: Part Two",
          type: "Movie",
          genres: ["Sci-Fi", "Adventure"],
          year: 2024,
          rating: 4.7,
          poster: "./posters/dune_part_two.jpg"
        },
        {
          id: "free-guy",
          title: "Free Guy",
          type: "Movie",
          genres: ["Comedy", "Sci-Fi"],
          year: 2021,
          rating: 4.0,
          poster: "./posters/free_guy.jpg"
        }
      ]
    },
    {
      id: "featured",
      title: "Featured",
      items: [
        {
          id: "mad-max-furiosa",
          title: "Furiosa: A Mad Max Saga",
          type: "Movie",
          genres: ["Action", "Adventure"],
          year: 2024,
          rating: 4.4,
          poster: "./posters/furiosa.webp"
        },
        {
          id: "mission-impossible-drd",
          title: "Mission: Impossible – Dead Reckoning",
          type: "Movie",
          genres: ["Action", "Thriller"],
          year: 2023,
          rating: 4.3,
          poster: "./posters/mi_dead_reckoning.jpg"
        },
        {
          id: "superman-legacy",
          title: "Superman: Legacy",
          type: "Movie",
          genres: ["Action", "Adventure"],
          year: 2025,
          rating: 4.3,
          poster: "./posters/superman_legacy.jpeg"
        },
        {
          id: "wednesday-s2",
          title: "Wednesday (Season 2)",
          type: "TV",
          genres: ["Horror", "Mystery"],
          year: 2025,
          rating: 4.8,
          poster: "./posters/wednesday_s2.jpg"
        },
        {
          id: "the-whale",
          title: "The Whale",
          type: "Movie",
          genres: ["Drama"],
          year: 2022,
          rating: 4.1,
          poster: "./posters/the_whale.jpg"
        },
        {
          id: "the-black-phone",
          title: "The Black Phone",
          type: "Movie",
          genres: ["Horror", "Thriller"],
          year: 2021,
          rating: 4.2,
          poster: "./posters/the_black_phone.jpg"
        },
        {
          id: "blue-eye-samurai",
          title: "Blue Eye Samurai",
          type: "TV",
          genres: ["Action", "Drama"],
          year: 2023,
          rating: 4.6,
          poster: "./posters/blue_eye_samurai.jpg"
        }
      ]
    },
    {
      id: "top-10",
      title: "Top 10 on CineGrid",
      items: [
        {
          id: "the-conjuring-last-rites",
          title: "The Conjuring: Last Rites",
          type: "Movie",
          genres: ["Horror", "Thriller"],
          year: 2024,
          rating: 4.2,
          poster: "./posters/conjuring_last_rites.jpeg"
        },
        {
          id: "oppenheimer",
          title: "Oppenheimer",
          type: "Movie",
          genres: ["Drama", "History"],
          year: 2023,
          rating: 4.8,
          poster: "./posters/oppenheimer.jpeg"
        },
        {
          id: "wednesday-s2",
          title: "Wednesday (Season 2)",
          type: "TV",
          genres: ["Horror", "Mystery"],
          year: 2025,
          rating: 4.8,
          poster: "./posters/wednesday_s2.jpg"
        },
        {
          id: "the-black-phone",
          title: "The Black Phone",
          type: "Movie",
          genres: ["Horror", "Thriller"],
          year: 2021,
          rating: 4.2,
          poster: "./posters/the_black_phone.jpg"
        },
        {
          id: "dune-part-two",
          title: "Dune: Part Two",
          type: "Movie",
          genres: ["Sci-Fi", "Adventure"],
          year: 2024,
          rating: 4.7,
          poster: "./posters/dune_part_two.jpg"
        },
        {
          id: "dexter-resurrection",
          title: "Dexter: Resurrection",
          type: "TV",
          genres: ["Thriller", "Crime"],
          year: 2025,
          rating: 4.2,
          poster: "./posters/dexter_resurrection.jpeg"
        },
        {
          id: "mad-max-furiosa",
          title: "Furiosa: A Mad Max Saga",
          type: "Movie",
          genres: ["Action", "Adventure"],
          year: 2024,
          rating: 4.4,
          poster: "./posters/furiosa.webp"
        }
      ]
    }
  ]
};
